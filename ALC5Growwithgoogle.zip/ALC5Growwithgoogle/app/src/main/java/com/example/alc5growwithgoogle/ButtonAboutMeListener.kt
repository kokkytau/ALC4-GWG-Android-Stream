package com.example.alc5growwithgoogle


import android.view.View
import android.widget.Button

class button2 : button2_about_me  Listener(
private val button2_about_me: Button) : View.OnClickListener
{


    @Override
    fun onClick(v: View) {

    }
}
