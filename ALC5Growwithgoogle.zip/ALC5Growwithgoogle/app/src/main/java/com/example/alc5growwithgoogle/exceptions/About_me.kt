package com.example.alc5growwithgoogle.exceptions

class About_meException(message: String) : Exception(message)
