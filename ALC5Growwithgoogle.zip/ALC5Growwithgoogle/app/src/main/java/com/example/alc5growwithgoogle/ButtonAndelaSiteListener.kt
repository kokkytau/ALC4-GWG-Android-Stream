package com.example.alc5growwithgoogle

import android.view.View
import android.widget.Button

abstract class button(private val btnPointerException: KotlinNullPointerException: Button) : View.OnClickListener {
    @Override
    fun onclick(v: View) {

    }
}
