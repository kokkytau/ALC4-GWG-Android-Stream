@file:Suppress("SyntaxError", "SyntaxError")

package com.example.alc5growwithgoogle

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.example.alc5growwithgoogle.exceptions.About_meException
import com.google.android.material.snackbar.Snackbar

class AboutMe extends AppCompatActivity {

    private lateinit var textValuesArray: Array<String>
    private var tvName: TextView? = null
    private var tvTrack: TextView? = null
    private var tvCountry: TextView? = null
    private var tvEmail: TextView? = null
    private var tvPhone: TextView? = null
    private var tvSlack: TextView? = null

    @Override
    protected fun onCreate(savedInstanceState: Bundle) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_me)
        val toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        try {
            textValuesArray = readTextViewValues()
            setProfileValues(textValuesArray)
        } catch (e: About_meException) {
            Toast.makeText(this, "there was as an error processing your request", Toast.LENGTH_LONG)
        }

    }

    @Throws(Alc4ProfileException::class)
    private fun setProfileValues(textValuesArray: Array<String>) {
        tvName = findViewById(R.id.textview_name) as TextView
        tvTrack = findViewById(R.id.textview_track) as TextView
        tvCountry = findViewById(R.id.textview_country) as TextView
        tvEmail = findViewById(R.id.textview_email) as TextView
        tvPhone = findViewById(R.id.textview_phone) as TextView
        tvSlack = findViewById(R.id.textview_slack) as TextView

        tvName!!.text = textValuesArray[0].toUpperCase()
        tvTrack!!.text = textValuesArray[1].toUpperCase()
        tvCountry!!.text = textValuesArray[2].toUpperCase()
        tvEmail!!.text = textValuesArray[3].toUpperCase()
        tvPhone!!.text = textValuesArray[4].toUpperCase()
        tvSlack!!.text = textValuesArray[5].toUpperCase()
    }

    @Throws(About_meException::class)
    private fun readTextViewValues(): Array<String> {

        try {
            val inputStream = getAssets().open("profile")
            val size = inputStream.available()
            val profilebytes = ByteArray(size)
            inputStream.read(profilebytes)
            inputStream.close()
            val textValue = kotlin.String(profilebytes)

            textValuesArray = textValue.split(",")
            System.out.println("the number of items in array is " + textValuesArray.size)

        } catch (e: IOException) {
            e.printStackTrace()
        }

        return textValuesArray

        `return`.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
        supportActionBar.setDisplayHomeAsUpEnabled(true)
    }

}
