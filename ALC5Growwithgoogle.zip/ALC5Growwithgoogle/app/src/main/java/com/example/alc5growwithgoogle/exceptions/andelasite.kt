package com.example.alc5growwithgoogle.exceptions


class AndelaSiteException(message: String) : Exception(message)
